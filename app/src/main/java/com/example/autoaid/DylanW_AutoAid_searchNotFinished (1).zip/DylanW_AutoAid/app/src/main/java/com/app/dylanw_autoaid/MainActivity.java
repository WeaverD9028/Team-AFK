package com.app.dylanw_autoaid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.app.dylanw_autoaid.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {


    //https://www.figma.com/file/vu01H9TWjdx2su8TNu0eGI/AutoAid-Design?node-id=0%3A1

    /*
    Android Studio calls app pages Activities
    Every activity will have
        -an XML file - this is just the layout of where the elements will be
        - a java file - this is the logic, what should happen when buttons are pressed, text is entered, etc

     XML Files are stored in "res"  resources folder



     */

    //This is how we will interact with items that are on the screen
    // binding.*name of XML element* will give us access to that item
    ActivityMainBinding binding;

    //In order to use the spinner we need a list of options to display in the drop down
    public static final String allIssues[] = { "NONE" ,"FLAT TIRES", "SQUEAKY OR GRINDY BREAKS", "CAR WILL NOT START", "SHAKY STEERING WHEEL",
            "NOISY ENGINE", "A/C ISSUES", "WARNING LIGHT(S)" };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        //In order to add items to a spinner we need an ArrayAdapter
        //-This takes text and shows it in some list. It basically maps data to an xml element
        //                                                               the layout to be used
        //Android has a simple built in layout for showing one string on a line and it's under android.R.id.simple
        ArrayAdapter<String> adpIssues = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, allIssues);
        //Now that we have something that can take Strings and show them in a list we need to set this adapter
        //as the adapter for our spinner
        binding.spnIssues.setAdapter(adpIssues);

        //All XML elements can listen for when they are clicked so let's setup the onlick listeners
        binding.btnIssuesContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMessage("Clicked Continue");
            }
        });

        binding.btnIssuesBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMessage("Clicked Back");
            }
        });

        binding.txtMoreIssues.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMessage("Go to more issues page");
            }
        });



    }

    private void showMessage(String msg){
        //Android Studio has something called a Toast and that will pop up a short message on the bottom of the screen
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}