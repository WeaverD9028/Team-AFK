package com.app.dylanw_autoaid;

//import allIssues array from the Main Activity page
import static com.app.dylanw_autoaid.MainActivity.allIssues;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.app.dylanw_autoaid.databinding.ActivityMainBinding;
import com.app.dylanw_autoaid.databinding.ActivitySearchIssuesBinding;

import java.util.ArrayList;

public class SearchIssues extends AppCompatActivity {

    ActivitySearchIssuesBinding binding;

    //We are going to show a list of issues, and we want to be able to search that list
    //To pull this off we actually need to keep 2 different lists
    //  - ALL POSSIBLE ISSUES
    //  - THE FILTERED RESULTS (when nothing is searched this is all issues)

    //allIssues is defined in the Main Activity

    //use an array list to show the filtered data so that we can clear and add as necessary
    ArrayList<String> filteredList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySearchIssuesBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        //the filtered list needs to be initialized
        filteredList = new ArrayList<>();



    }

    private void filterIssues(String searchText){
        //clear the filtered list
        filteredList.clear();

        //search: EE
        // none
        // steering wheel
        // wheel problem
        //

        //go through all of the issues we have and
        for(int i = 0; i < allIssues.length; i++ ){
            String currentIssue = allIssues[i];
            if ( currentIssue.contains(searchText)){
                //add to the filtered list
                filteredList.add(currentIssue);
            }
        }

        //TODO notify datasetchanged

    }
}